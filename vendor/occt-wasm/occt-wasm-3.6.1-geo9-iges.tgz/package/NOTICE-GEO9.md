# occt-wasm 3.6.1 -- GEO-9 / BK-65 patched build

This is a locally rebuilt, patched drop-in for the upstream `occt-wasm@3.6.1`
package (https://github.com/andymai/occt-wasm, tag v3.6.1, commit
c4a96db7bb6ec7eed294dec42ba92fe4b6e0f580; OCCT submodule
6e1fe656bf028bf0004482c389661587b269fc65).

This file is the master copy. A copy of it ships inside the package at
`vendor/occt-wasm/occt-wasm-3.6.1-geo9-bk65.tgz` (`package/NOTICE-GEO9.md`);
that copy was written when the tarball was packed on 2026-07-09 and is NOT
rewritten by this one - WO-1836 deliberately did not repack the tarball. The
two differ only in the "How to reproduce" section, which was wrong there and is
corrected here; see the last section.

## What changed

`defeature()` was rebound from the stock zero-thickness thick-solid shell path
(`BRepOffsetAPI_MakeThickSolid::MakeThickSolidByJoin(..., 0.0, tolerance)`, which
threw a `WebAssembly.Exception` on real inputs) to OCCT's real feature-removal
algorithm `BRepAlgoAPI_Defeaturing` (which drives `BOPAlgo_RemoveFeatures`), plus
a single-solid-compound unwrap so `isSolid()` / `watertight()` report correctly on
geometrically valid results. The public API signature is unchanged.

The change lives in the codegen SOURCE (`xtask/src/codegen/config.rs`, the
`defeature` MethodSpec) and is emitted by `cargo xtask codegen` into
`facade/generated/kernel.cpp`. It is committed in this repository as
`patches/occt-wasm-3.6.1-geo9-defeature.patch`, against the vendored pristine
copy of that file in `xtask/`.

## Artifact hashes (the shipped build)

- `dist/occt-wasm.wasm`  sha256 = a3c02c79e435b21b3a37acc70912a0ce0c0ab8acb24a0a6fbdabb3534360ec44  (22,158,771 bytes)
- `dist/occt-wasm.js`    sha256 = 2d3285281a20b8c5668dc52e543b5e04164abb0d126ca9f746e03adc40b984c4
- `dist/index.js`        sha256 = 67de8bcd3e15dd7fbb4ad333571100fff669fb8c91e8e20ce57d8db67f50b3f5
- tarball `occt-wasm-3.6.1-geo9-bk65.tgz` sha256 =
  6cdf9b3b5a21dd352b86fac34e12200d7be2fbd2dc6df8ce8728029a059ba76b

## LGPL-2.1 source availability (OCCT)

The compiled `.wasm` embeds OpenCASCADE Technology, licensed LGPL-2.1-only. To
satisfy LGPL replaceability the consuming app loads the `.wasm` via an explicit,
overridable URL/bytes (`OcctKernel.init({ wasm })`); replace the binary to relink.

Full corresponding source is the upstream repo/tag above plus the local diff, both
of which are in this repository: `xtask/` (pristine upstream copy of the build
tool) and `patches/occt-wasm-3.6.1-geo9-defeature.patch`.

Upstream build tooling + the TypeScript wrapper are MIT OR Apache-2.0.

## How to reproduce

`Dockerfile` at the root of this repository is the recipe: emsdk 5.0.3 base,
upstream source fetched at the pinned commits, then

```
patch -p1 < patches/occt-wasm-3.6.1-geo9-defeature.patch
rm -rf facade/generated
cargo xtask codegen
cargo xtask build --release
```

The `rm -rf facade/generated` matters. `cargo xtask build` regenerates the facade
ONLY when `facade/generated/` is missing, and upstream commits that directory, so
without deleting it first the patch compiles to nothing. The packaged copy of this
notice (and `THIRD-PARTY-NOTICES.md` before WO-1836) claimed upstream's Dockerfile
already ran codegen; it does not, and never did. On 2026-07-09 that step was run by
hand. The `Dockerfile` committed here runs it explicitly.

`src/tests/evidence/WO-1836/GEO-9.report.json` records the pins, hashes and the
WO-1836 reproduction result. The packaged copy of this notice cites
`coordination/reports/GEO-9.report.json` instead; that directory is banned by
`.gitignore` ("coordination/ must never exist in this repo"), which is part of
why the file never existed.
